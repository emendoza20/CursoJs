(M7.2.) Exercici 2. Dibuixa un triangle invertit.
Oberta el dimarts, 11 de gener 2022, 23:00
Pendent: Fer una tramesa
Descripció
Fes un programa que mostri el següent per pantalla:

* * * * * *

* * * * *

* * * *

* * *

* *

*

El nombre de línies formades per “*” vindrà donat per un número que l’usuari/ària introduirà per consola.

Condició: En tot el codi del programa només hi pot haver un *

També, a poder ser, no utilitzis cap mètode com repeat() o substring() de la classe String