function Draw_Triangle_Reverse() {

  //  debugger
    const userNumber = Number(document.getElementById("num1").value)


    // let result = "";

    const array = [];
    for (let i = userNumber; i >= 1; i--) {

        // let result=""


        // result = result + "*";// concateno el asterisco 
        array.push("*");
        //  document.getElementById('result').innerHTML = ` ${array.join('<br>')}`


    }
    // document.getElementById('result').innerHTML = ` ${array.join('<br>')}`





    //document.getElementById('result').innerHTML = ` ${array.join('<br>')}`
    document.getElementById('result').innerHTML = ` ${array.join()}`
    
    while(array.length!=0)
    {
       // print_array(array)
    // document.getElementById('result').innerHTML = ` ${array.join('<br>')}`
        array.pop();
        //document.getElementById('result').innerHTML = ` ${array.join('<br>')}`
    }

    
    
}


function print_array(array){

    for (let index = 0; index < array.length; index++) {

        console.log(array);
        
        
    }



}