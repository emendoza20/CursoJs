
function printPrime() {

    const numero = document.getElementById("number").value


    const result = esPrime(numero) ? "Es primo" : "No es primo";

    document.getElementById("result").innerHTML = `${numero}  ${result}.`;


}



function esPrime(num) {



    if (num== 0 || num == 1 || num== 4)
        return false;

    for (let i = 2; i < num; i++) {
        if (num % i === 0)
            return false

    }

    // Si no se pudo dividir por ninguno de los de arriba, sí es primo
    return true;



}

