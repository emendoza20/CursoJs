(M7.1.) Exercici 4. Indica si un dels nombres és negatiu

L’usuari/ària ha d’introduir dos números, el programa retornarà “Un dels dos números és negatiu”, només si un dels dos números és negatiu.

Pasos:
html
1) introducir los dos numeros mediante un input

js

1 hacer condicional y evaluar si es <0 indica que el numero es negativo