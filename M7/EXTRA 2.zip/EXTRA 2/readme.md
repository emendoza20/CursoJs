El usuario/a debe introducir un número y el programa debe mostrar por pantalla si el número es par o impar.

Solucion

html

pedimos mediante un input el numero

js


mostramos mediante inner.html si es par o no el  numero introducido

mediante el modulo  % divido entre 2 si el resto da cero (0) el numero es par