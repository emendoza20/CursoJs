(M7.1.) Exercici 1. Calcula la mitja de tres notes i indica si has aprovat o suspès

Crea un programa en el que el usuario introduce tres notas y el programa calcule la media.

Si la media es inferior a 5 debe mostrar el siguiente mensaje por pantalla: “No has superado el curso. Tienes que recuperar”.

Si la media está entre 5 y 7 debe mostrar: “¡Enhorabuena! Has aprobado, pero deberías seguir practicando”.

Si la media es superior a 7 debe mostrar: "¡Enhorabuena! ¡Has superado el curso! ¡Pasa ya al siguiente nivel!"

Pasos a seguir:

1 html
 crear 3 inputs solicitando la entrada de las tres notas al usuario

 crear la funcion ObtenerMedia con button

 2 js

 Pido la entrada de 3 notas cone elemetgetbyid

 se crea una variable donde calculara la media de las 3 notas


 luego un condicional donde se evaluen las 3 condiciones solicitadas por el ejercicio

 el mensaje se imprime en el html con el el elemento inner.html
