Realizar un juego para adivinar un número aleatorio N entre 1 y 500.

Si la distancia entre el número a adivinar y el del usuario/a es de 50 o más, el programa deberá decir:

“Fred, frío: tu número es mayor” o “Fred, frío: tu número es más pequeño”



Si la distancia entre el número a adivinar y el del usuario/a está entre 15 y 50, el programa deberá decir:

"Tebi, Tebi: tu número es mayor" o "Tebi, Tebi: tu número es más pequeño"



Y si la distancia entre el número a adivinar y el del usuario/ay si la distancia es menor a 15, el programa deberá decir:

“Caliente, caliente: tu número es mayor” o “Caliente, caliente: tu número es más pequeño”

El proceso termina cuando el usuario acierta