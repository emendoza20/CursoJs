function suma()
{


    //debugger
    let miarray = [2,1,3];

    
    resultPares=0;
    resultImpares=0;

    for(i=0;i<=(miarray.length-1);i++){

        if(miarray[i]%2===0)
        {
            resultPares=resultPares+miarray[i]

        }else if(miarray[i]%2!==0){

            resultImpares=resultImpares+miarray[i]
        }
    }

    console.log(`el resultado de los pares es: ${resultPares}`)
    console.log(`el resultado de los impares es: ${resultImpares}`)






}